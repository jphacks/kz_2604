import { test } from "node:test";
import assert from "node:assert/strict";
import { decideRescue, initialMenu, simulateWeek } from "../src/logic/rescue.js";

test("水曜に無理と言うと、豚こまを冷凍、もやしを明日の朝に回す", () => {
  const r = decideRescue(initialMenu(), "wed");
  assert.equal(r.message, "豚こまは袋のまま冷凍庫へ。もやしは明日の朝、卵とレンジで3分");
  assert.deepEqual(r.frozen, ["pork"]);
  assert.deepEqual(r.tomorrow, ["moyashi"]);
  assert.deepEqual(r.changedDays, ["wed", "thu", "sat"]);
  assert.equal(r.newMenu.find((m) => m.day === "thu")?.note, "朝：もやし");
});

test("アプリありの1週間は捨てたもの0、崩れた日にも自分で食べた回数3", () => {
  const w = simulateWeek(true);
  assert.deepEqual(w.wasted, []);
  assert.equal(w.selfMealsOnBadDays, 3);
});

test("アプリなしの1週間は4品捨てる", () => {
  const w = simulateWeek(false);
  assert.deepEqual(w.wasted, ["豚こま", "もやし", "豆腐", "合いびき肉"]);
  assert.equal(w.selfMealsOnBadDays, 0);
});
