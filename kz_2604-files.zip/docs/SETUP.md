# 救済Bot（ハッカソン デモ）

疲れて自炊の予定が崩れた瞬間に、30秒でできる行動を1つだけLINEで返すBotです。

- `/demo` デモ操作ページ。「水曜 18:00」「返事なしで30分」「土曜」「リセット」のボタンと、組み直した献立、土曜の「アプリなし／あり」の1週間
- `/chat` ブラウザ版（LINE風の画面）。LINEが動かないときの保険
- `/webhook` LINEのWebhook

## 構成

| ファイル | 中身 |
| --- | --- |
| `src/logic/data.ts` | 食材表と献立（仮データ。食材表ができたら差し替え） |
| `src/logic/rescue.ts` | 判定ロジック `decideRescue` と `simulateWeek`。LINEに依存しない純粋関数 |
| `src/engine.ts` | デモの流れ（問いかけ→無理→行動→ふり返り、合言葉） |
| `src/line.ts` | Flex Messageへの変換、返信とプッシュ |
| `src/app.ts` | Honoのルート |
| `src/pages.ts` | 操作ページとブラウザ版のHTML |
| `src/store.ts` | 状態の保存（Upstash Redis、なければメモリ） |

## ローカルで動かす（ブラウザ版の保険もこれ）

```bash
npm install
npm run dev
# http://localhost:3000/demo を開く。LINE未設定なら右にブラウザ版が出る
npm test
```

ネットがなくても動きます。本番当日はPCでこれを起動したまま待機しておきます。

## LINEとVercelの設定

1. [LINE Official Account Manager](https://manager.line.biz/) で公式アカウントを作り、設定 → Messaging API で有効化する
2. 応答設定で「応答メッセージ」をオフ、「Webhook」をオンにする
3. [LINE Developers](https://developers.line.biz/console/) のチャネルで、チャネル基本設定の「チャネルシークレット」と、Messaging API設定の「チャネルアクセストークン（長期）」を発行して控える
4. [Vercel](https://vercel.com/new) でこのリポジトリをインポートする（設定はそのままでOK）
5. Vercelの Storage（Marketplace）から Upstash Redis を追加してプロジェクトにつなぐ
6. Vercelの Settings → Environment Variables に `LINE_CHANNEL_SECRET` と `LINE_CHANNEL_ACCESS_TOKEN` を入れて Redeploy
7. LINE Developers の Webhook URL に `https://<VercelのURL>/webhook` を入れて「検証」
8. QRコードで友だち追加し、何か送る。オウム返しされれば完了（この時点でプッシュ先として登録される）

`/demo` の上に「LINE接続済み · 送り先あり · 状態: Redis」と出ていれば準備完了です。

## デモの手順

1. `/demo` で「リセット」
2. 「水曜 18:00」→ スマホに問いかけが届く →「無理」
3. 行動が返り、操作ページの献立が光る →「した」
4. 「土曜」→ ふり返りカードが届き、操作ページに「アプリなし／あり」が並ぶ

プッシュが届かないときは、スマホから「デモ」と送ると同じ問いかけが返ります。土曜は「ふり返り」、やり直しは「リセット」。どちらも応答メッセージなので無料枠を使いません。

LINEごと動かないときは、操作ページの「ブラウザ版で見せる」にチェックを入れるか、ローカルの `npm run dev` に切り替えます。
