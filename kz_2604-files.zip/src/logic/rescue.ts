// 判定ロジック。LINEにもサーバーにも依存しない純粋関数だけを置く。
import { DAYS, DAY_LABEL, PURCHASE_DAY, ingredients, menu as baseMenu } from "./data.js";
import type { Day, Ingredient, MenuDay } from "./data.js";

const byId = new Map(ingredients.map((i) => [i.id, i]));

export function getIngredient(id: string): Ingredient {
  const found = byId.get(id);
  if (!found) throw new Error(`unknown ingredient: ${id}`);
  return found;
}

export function dayIndex(day: Day): number {
  return DAYS.indexOf(day);
}

// 残り日数＝冷蔵日数−購入からの日数。0 が使える最終日
export function remainingDays(id: string, today: Day): number {
  return getIngredient(id).fridgeDays - (dayIndex(today) - dayIndex(PURCHASE_DAY));
}

export function cloneMenu(menu: MenuDay[]): MenuDay[] {
  return menu.map((m) => ({ ...m, ingredients: [...m.ingredients] }));
}

export function initialMenu(): MenuDay[] {
  return cloneMenu(baseMenu);
}

export function dishOf(menu: MenuDay[], day: Day): MenuDay | undefined {
  return menu.find((m) => m.day === day);
}

export type RescueResult = {
  message: string;
  frozen: string[];
  tomorrow: string[];
  newMenu: MenuDay[];
  changedDays: Day[];
};

// 「無理」と言われた日に返す行動1つと、組み直した献立
export function decideRescue(menu: MenuDay[], today: Day): RescueResult {
  const todayEntry = dishOf(menu, today);
  const items = [...(todayEntry?.ingredients ?? [])]
    .filter((id) => remainingDays(id, today) >= 0)
    .sort((a, b) => remainingDays(a, today) - remainingDays(b, today));

  const frozen = items.filter((id) => getIngredient(id).freezable);
  const tomorrow = items.filter((id) => !getIngredient(id).freezable);

  const sentences = items.map((id) => {
    const ing = getIngredient(id);
    return `${ing.name}は${ing.freezable ? ing.rescueFreeze : ing.rescueTomorrow}`;
  });
  const message = sentences.length > 0 ? sentences.join("。") : "今日は何もしなくて大丈夫。ゆっくり休んで";

  // 組み直しのルールはこれだけ：今日の献立を消し、朝に回す食材は翌日の朝に、冷凍した食材は土曜の冷凍ストックに回す
  const newMenu = cloneMenu(menu);
  const changedDays: Day[] = [];
  const t = dishOf(newMenu, today);
  if (t && todayEntry && todayEntry.ingredients.length > 0) {
    t.note = [t.note, `${t.dish}はお休み`].filter(Boolean).join(" / ");
    t.ingredients = [];
    changedDays.push(today);
  }

  const next = DAYS[dayIndex(today) + 1];
  const nextEntry = next ? dishOf(newMenu, next) : undefined;
  if (nextEntry && tomorrow.length > 0) {
    const names = tomorrow.map((id) => getIngredient(id).name).join("・");
    nextEntry.note = [nextEntry.note, `朝：${names}`].filter(Boolean).join(" / ");
    if (!changedDays.includes(next)) changedDays.push(next);
  }

  const sat = dishOf(newMenu, "sat");
  if (sat && frozen.length > 0 && today !== "sat") {
    sat.ingredients = [...new Set([...sat.ingredients, ...frozen])];
    sat.dish = `冷凍ストックで1品（${sat.ingredients.map((id) => getIngredient(id).name).join("・")}）`;
    if (!changedDays.includes("sat")) changedDays.push("sat");
  }

  return { message, frozen, tomorrow, newMenu, changedDays };
}

export type WeekLine = { day: Day; text: string };

export type WeekResult = {
  wasted: string[];
  selfMealsOnBadDays: number;
  timeline: WeekLine[];
};

// デモで見せる「崩れ方」：水曜と木曜に疲れて作れない
export const BAD_DAYS: Day[] = ["wed", "thu"];

// 同じ崩れ方をした1週間を、アプリあり／なしで計算する
export function simulateWeek(withApp: boolean, badDays: Day[] = BAD_DAYS): WeekResult {
  let menu = initialMenu();
  const used = new Set<string>();
  const frozen = new Set<string>();
  const timeline: WeekLine[] = [];
  let selfMeals = 0;
  // 前日の救済で「明日の朝」に回した食材
  let morning: string[] = [];

  for (const day of DAYS) {
    const parts: string[] = [];

    if (morning.length > 0) {
      morning.forEach((id) => used.add(id));
      selfMeals += 1;
      parts.push(`朝に${morning.map((id) => getIngredient(id).name).join("・")}を食べた`);
      morning = [];
    }

    const entry = dishOf(menu, day);
    if (day === "sat") {
      if (withApp && entry && entry.ingredients.length > 0) {
        entry.ingredients.forEach((id) => used.add(id));
        selfMeals += 1;
        parts.push(`${entry.dish}を作った`);
      } else {
        parts.push("ふり返り");
      }
    } else if (badDays.includes(day)) {
      if (withApp) {
        const r = decideRescue(menu, day);
        r.frozen.forEach((id) => frozen.add(id));
        morning = r.tomorrow;
        menu = r.newMenu;
        parts.push(`崩れた → ${r.message}`);
      } else {
        parts.push("崩れた → コンビニ弁当");
      }
    } else if (entry) {
      const usable = entry.ingredients.filter((id) => remainingDays(id, day) >= 0);
      usable.forEach((id) => used.add(id));
      parts.push(`${entry.dish}を作った`);
    }

    timeline.push({ day, text: parts.join("。") });
  }

  const bought = [...new Set(initialMenu().flatMap((m) => m.ingredients))];
  const wasted = bought
    .filter((id) => !used.has(id) && !frozen.has(id))
    .map((id) => getIngredient(id).name);

  return { wasted, selfMealsOnBadDays: selfMeals, timeline };
}

export function dayLabel(day: Day): string {
  return DAY_LABEL[day];
}
