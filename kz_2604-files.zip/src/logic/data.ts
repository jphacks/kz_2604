// デモ用の食材表と献立（仮データ）。C担当の食材表ができたらここを差し替える。
// 購入はすべて月曜。fridgeDays は冷蔵で使える日数。

export type Day = "mon" | "tue" | "wed" | "thu" | "fri" | "sat";

export const DAYS: Day[] = ["mon", "tue", "wed", "thu", "fri", "sat"];

export const DAY_LABEL: Record<Day, string> = {
  mon: "月",
  tue: "火",
  wed: "水",
  thu: "木",
  fri: "金",
  sat: "土",
};

export type Ingredient = {
  id: string;
  name: string;
  fridgeDays: number;
  freezable: boolean;
  rescueFreeze: string;
  rescueTomorrow: string;
};

export type MenuDay = {
  day: Day;
  dish: string;
  ingredients: string[];
  // 組み直しで足された朝ごはんなど
  note?: string;
};

export const ingredients: Ingredient[] = [
  { id: "chicken", name: "鶏むね", fridgeDays: 2, freezable: true, rescueFreeze: "ラップで包んで冷凍庫へ", rescueTomorrow: "明日の朝、塩をふってレンジで4分" },
  { id: "cabbage", name: "キャベツ", fridgeDays: 7, freezable: false, rescueFreeze: "ざく切りにして冷凍庫へ", rescueTomorrow: "明日の朝、ちぎって味噌汁に" },
  { id: "salmon", name: "生鮭", fridgeDays: 2, freezable: true, rescueFreeze: "1切れずつラップして冷凍庫へ", rescueTomorrow: "明日の朝、魚焼きグリルで7分" },
  { id: "shimeji", name: "しめじ", fridgeDays: 5, freezable: true, rescueFreeze: "石づきを取って袋ごと冷凍庫へ", rescueTomorrow: "明日の朝、味噌汁に入れる" },
  { id: "pork", name: "豚こま", fridgeDays: 3, freezable: true, rescueFreeze: "袋のまま冷凍庫へ", rescueTomorrow: "明日の朝、塩こしょうで炒めて2分" },
  { id: "moyashi", name: "もやし", fridgeDays: 3, freezable: false, rescueFreeze: "袋のまま冷凍庫へ", rescueTomorrow: "明日の朝、卵とレンジで3分" },
  { id: "tofu", name: "豆腐", fridgeDays: 5, freezable: false, rescueFreeze: "パックごと冷凍庫へ", rescueTomorrow: "明日の朝、レンジで温やっこ1分" },
  { id: "hikiniku", name: "合いびき肉", fridgeDays: 4, freezable: true, rescueFreeze: "袋の上から平らにして冷凍庫へ", rescueTomorrow: "明日の朝、そぼろにして3分" },
  { id: "carrot", name: "にんじん", fridgeDays: 14, freezable: false, rescueFreeze: "細切りにして冷凍庫へ", rescueTomorrow: "明日の朝、スープに入れる" },
  { id: "onion", name: "玉ねぎ", fridgeDays: 30, freezable: false, rescueFreeze: "薄切りにして冷凍庫へ", rescueTomorrow: "明日の朝、スープに入れる" },
];

export const menu: MenuDay[] = [
  { day: "mon", dish: "鶏むねの照り焼き", ingredients: ["chicken", "cabbage"] },
  { day: "tue", dish: "鮭のホイル焼き", ingredients: ["salmon", "shimeji"] },
  { day: "wed", dish: "豚もやし炒め", ingredients: ["pork", "moyashi"] },
  { day: "thu", dish: "麻婆豆腐", ingredients: ["tofu", "hikiniku"] },
  { day: "fri", dish: "野菜カレー", ingredients: ["carrot", "onion"] },
  { day: "sat", dish: "（作り置きなし）", ingredients: [] },
];

export const PURCHASE_DAY: Day = "mon";
