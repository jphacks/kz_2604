import { Hono } from "hono";
import { validateSignature } from "@line/bot-sdk";
import type { webhook } from "@line/bot-sdk";
import * as engine from "./engine.js";
import type { Msg, Outcome, State } from "./engine.js";
import { channelSecret, lineConfigured, push, reply } from "./line.js";
import { loadState, saveState, storeKind } from "./store.js";
import { chatPage, demoPage } from "./pages.js";

export const app = new Hono();

function logged(state: State, from: "bot" | "user", messages: Msg[]): State {
  const at = Date.now();
  return { ...state, chat: [...state.chat, ...messages.map((msg) => ({ from, msg, at }))] };
}

function userText(text: string): Msg {
  return { kind: "text", text };
}

// 操作ページから進めたときの送り先。LINEモードならプッシュ、ブラウザ版なら履歴に残すだけ
async function deliver(out: Outcome): Promise<State> {
  const state = logged(out.state, "bot", out.messages);
  await saveState(state);
  if (state.channel === "line" && lineConfigured && state.userId) {
    await push(state.userId, out.messages);
  }
  return state;
}

app.get("/", (c) => c.redirect("/demo"));
app.get("/demo", (c) => c.html(demoPage()));
app.get("/chat", (c) => c.html(chatPage()));

app.get("/api/state", async (c) => {
  const state = await loadState();
  return c.json({
    state,
    week: engine.weekComparison(),
    meta: { lineConfigured, storeKind, hasUser: Boolean(state.userId) },
  });
});

app.post("/api/demo/:action", async (c) => {
  const state = await loadState();
  const action = c.req.param("action");
  let out: Outcome;
  switch (action) {
    case "wed":
      out = engine.goWednesday(state);
      break;
    case "noreply":
      out = engine.noReply(state);
      break;
    case "sat":
      out = engine.goSaturday(state);
      break;
    case "reset":
      out = engine.reset(state);
      break;
    case "channel": {
      const body = await c.req.json<{ channel: State["channel"] }>();
      out = { state: { ...state, channel: body.channel === "browser" ? "browser" : "line" }, messages: [] };
      break;
    }
    default:
      return c.json({ error: "unknown action" }, 404);
  }
  try {
    return c.json({ state: await deliver(out) });
  } catch (e) {
    console.error(e);
    return c.json({ error: "LINEへの送信に失敗しました。合言葉「デモ」かブラウザ版に切り替えてください" }, 502);
  }
});

// ブラウザ版の入力。LINEには送らず、同じ関数を通して履歴に残す
app.post("/api/chat", async (c) => {
  const body = await c.req.json<{ text?: string; postback?: string }>();
  let state = await loadState();
  let out: Outcome;
  if (body.postback) {
    state = logged(state, "user", [userText(engine.postbackLabel(body.postback))]);
    out = engine.onPostback(state, body.postback);
  } else {
    const text = body.text ?? "";
    state = logged(state, "user", [userText(text)]);
    out = engine.onText(state, text);
  }
  const next = logged(out.state, "bot", out.messages);
  await saveState(next);
  return c.json({ state: next });
});

app.post("/webhook", async (c) => {
  const raw = await c.req.text();
  const signature = c.req.header("x-line-signature") ?? "";
  if (!channelSecret || !validateSignature(raw, channelSecret, signature)) {
    return c.text("bad signature", 401);
  }

  const { events } = JSON.parse(raw) as webhook.CallbackRequest;
  for (const event of events) {
    try {
      await handleEvent(event);
    } catch (e) {
      console.error(e);
    }
  }
  return c.text("ok");
});

async function handleEvent(event: webhook.Event): Promise<void> {
  const userId = event.source?.type === "user" ? event.source.userId : undefined;
  let state = await loadState();
  if (userId) state = { ...state, userId };

  let out: Outcome;
  if (event.type === "message" && event.message.type === "text") {
    state = logged(state, "user", [userText(event.message.text)]);
    out = engine.onText(state, event.message.text);
  } else if (event.type === "postback") {
    state = logged(state, "user", [userText(engine.postbackLabel(event.postback.data))]);
    out = engine.onPostback(state, event.postback.data);
  } else if (event.type === "follow") {
    out = {
      state,
      messages: [{ kind: "text", text: "友だち追加ありがとう。疲れた日の夕方に、30秒でできることを1つだけ届けます" }],
    };
  } else {
    await saveState(state);
    return;
  }

  const next = logged(out.state, "bot", out.messages);
  await saveState(next);
  // ボタンと合言葉への返事は応答メッセージ（無料）で返す
  if ("replyToken" in event && event.replyToken) {
    await reply(event.replyToken, out.messages);
  }
}
