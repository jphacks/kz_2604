// デモの状態の保存先。Upstash Redis の環境変数があればRedis、なければメモリ（ローカル起動・ブラウザ版用）
import { Redis } from "@upstash/redis";
import { initialState } from "./engine.js";
import type { State } from "./engine.js";

const KEY = "demo:state";
const CHAT_LIMIT = 40;

const url = process.env.UPSTASH_REDIS_REST_URL ?? process.env.KV_REST_API_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN ?? process.env.KV_REST_API_TOKEN;
const redis = url && token ? new Redis({ url, token }) : undefined;

let memory: State | undefined;

export const storeKind = redis ? "redis" : "memory";

export async function loadState(): Promise<State> {
  if (redis) {
    const saved = await redis.get<State>(KEY);
    return saved ?? initialState();
  }
  return memory ?? initialState();
}

export async function saveState(state: State): Promise<void> {
  const trimmed = { ...state, chat: state.chat.slice(-CHAT_LIMIT) };
  if (redis) {
    await redis.set(KEY, trimmed);
  } else {
    memory = trimmed;
  }
}
