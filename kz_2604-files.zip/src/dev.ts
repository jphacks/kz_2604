// ローカル起動用（npm run dev）。ブラウザ版の保険もこれで動かす
import { serve } from "@hono/node-server";
import { app } from "./app.js";

const port = Number(process.env.PORT ?? 3000);
serve({ fetch: app.fetch, port }, () => {
  console.log(`デモ操作ページ: http://localhost:${port}/demo`);
  console.log(`ブラウザ版:     http://localhost:${port}/chat`);
});
