// デモの流れ。LINEでもブラウザ版でも同じ関数を通す。
// 返すメッセージは中立な形で、LINE用への変換は line.ts、画面表示は pages.ts が行う。
import type { Day, MenuDay } from "./logic/data.js";
import { decideRescue, dishOf, dayLabel, initialMenu, simulateWeek } from "./logic/rescue.js";

export type Button = { label: string; data: string; primary?: boolean };

export type Msg =
  | { kind: "text"; text: string }
  | { kind: "ask"; title: string; text: string; buttons: Button[] }
  | { kind: "summary"; wasted: number; selfMeals: number };

export type Phase = "idle" | "asked" | "rescued" | "done";

export type ChatEntry = { from: "bot" | "user"; msg: Msg; at: number };

export type State = {
  day: Day;
  time: string;
  phase: Phase;
  menu: MenuDay[];
  changedDays: Day[];
  // 変化のたびに増やす。操作ページが光らせるきっかけに使う
  version: number;
  // LINEで最後に話しかけてきた人。プッシュ先
  userId?: string;
  // "line" ならLINEにプッシュ、"browser" ならブラウザ版の画面にだけ出す
  channel: "line" | "browser";
  chat: ChatEntry[];
};

export function initialState(prev?: State): State {
  return {
    day: "tue",
    time: "21:00",
    phase: "idle",
    menu: initialMenu(),
    changedDays: [],
    version: (prev?.version ?? 0) + 1,
    userId: prev?.userId,
    channel: prev?.channel ?? "line",
    chat: [],
  };
}

const ASK_DAY: Day = "wed";

function askMessage(state: State): Msg {
  const dish = dishOf(state.menu, state.day)?.dish ?? "ごはん";
  return {
    kind: "ask",
    title: `${dayLabel(state.day)}曜 ${state.time}`,
    text: `おつかれさま。今日、${dish}作れそう？`,
    buttons: [
      { label: "作る", data: "action=make" },
      { label: "無理", data: "action=cant", primary: true },
    ],
  };
}

function summaryMessage(): Msg {
  const w = simulateWeek(true);
  return { kind: "summary", wasted: w.wasted.length, selfMeals: w.selfMealsOnBadDays };
}

// 状態を変え、送るメッセージを返す。呼び出し側で保存と送信をする
export type Outcome = { state: State; messages: Msg[] };

function bump(state: State): State {
  return { ...state, version: state.version + 1 };
}

// 操作ページ・合言葉：水曜18時に飛ばして問いかける
export function goWednesday(state: State): Outcome {
  const s = bump({ ...initialState(state), day: ASK_DAY, time: "18:00", phase: "asked" });
  return { state: s, messages: [askMessage(s)] };
}

// 操作ページ：返事なしで30分たった（無理とみなす）
export function noReply(state: State): Outcome {
  if (state.phase !== "asked") return { state, messages: [] };
  const later = { ...state, time: "18:30" };
  const out = rescue(later);
  return {
    state: out.state,
    messages: [{ kind: "text", text: "返事がなかったので、今日は無理な日として預かりました" }, ...out.messages],
  };
}

function rescue(state: State): Outcome {
  const r = decideRescue(state.menu, state.day);
  const s = bump({ ...state, phase: "rescued", menu: r.newMenu, changedDays: r.changedDays });
  return {
    state: s,
    messages: [
      {
        kind: "ask",
        title: "30秒だけ、これだけ",
        text: r.message,
        buttons: [
          { label: "した", data: "action=did", primary: true },
          { label: "まだ", data: "action=notyet" },
        ],
      },
    ],
  };
}

// 操作ページ・合言葉：土曜に飛ばしてふり返り
export function goSaturday(state: State): Outcome {
  const s = bump({ ...state, day: "sat", time: "10:00", phase: "done", changedDays: [] });
  return { state: s, messages: [summaryMessage()] };
}

export function reset(state: State): Outcome {
  return { state: initialState(state), messages: [] };
}

// ボタンが押されたとき
export function onPostback(state: State, data: string): Outcome {
  const action = new URLSearchParams(data).get("action");
  switch (action) {
    case "make": {
      const dish = dishOf(state.menu, state.day)?.dish ?? "ごはん";
      return {
        state: bump({ ...state, phase: "done" }),
        messages: [{ kind: "text", text: `いいね。${dish}、楽しんで` }],
      };
    }
    case "cant":
      if (state.phase === "rescued") return { state, messages: [] };
      return rescue(state);
    case "did":
      return {
        state: bump({ ...state, phase: "done" }),
        messages: [{ kind: "text", text: "ナイス。冷凍した分は土曜の献立に回しておきました。今日はもう休もう" }],
      };
    case "notyet":
      return {
        state,
        messages: [{ kind: "text", text: "大丈夫。寝る前に冷凍庫へ入れれば間に合います" }],
      };
    default:
      return { state, messages: [] };
  }
}

// 文字が送られたとき。合言葉は保険の経路（応答メッセージなので無料枠を使わない）
export function onText(state: State, text: string): Outcome {
  const t = text.trim();
  if (t === "デモ") return goWednesday(state);
  if (t === "ふり返り" || t === "振り返り") return goSaturday(state);
  if (t === "リセット") {
    const out = reset(state);
    return { state: out.state, messages: [{ kind: "text", text: "リセットしました" }] };
  }
  return { state, messages: [{ kind: "text", text: t }] };
}

// 押されたボタンの表示名。チャット履歴に残す
export function postbackLabel(data: string): string {
  const labels: Record<string, string> = { make: "作る", cant: "無理", did: "した", notyet: "まだ" };
  return labels[new URLSearchParams(data).get("action") ?? ""] ?? data;
}

export function weekComparison() {
  return { without: simulateWeek(false), with: simulateWeek(true) };
}
