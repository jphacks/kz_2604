// Vercel はこのファイルの default export（Honoアプリ）をそのまま動かす
import { app } from "./app.js";

export default app;
