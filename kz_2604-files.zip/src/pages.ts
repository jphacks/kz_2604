// デモ操作ページとブラウザ版（LINE風の画面）。どちらも /api/state を1秒ごとに読んで描き直す

const base = `
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { --green:#06C755; --ink:#1f2328; --muted:#6b7280; --line:#e5e7eb; --bg:#f6f7f9; }
  * { box-sizing:border-box; }
  body { margin:0; font-family: "Hiragino Sans", "Noto Sans JP", system-ui, sans-serif; color:var(--ink); background:var(--bg); }
  button { font:inherit; cursor:pointer; }
</style>`;

export function demoPage(): string {
  return `<!doctype html><html lang="ja"><head>${base}
<title>デモ操作</title>
<style>
  .wrap { display:flex; gap:24px; padding:24px; align-items:flex-start; }
  .main { flex:1; min-width:0; }
  h1 { font-size:20px; margin:0 0 4px; }
  .clock { font-size:44px; font-weight:800; margin:8px 0 16px; }
  .controls { display:flex; flex-wrap:wrap; gap:10px; margin-bottom:12px; }
  .controls button { padding:14px 20px; border-radius:12px; border:1px solid var(--line); background:#fff; font-size:18px; font-weight:700; }
  .controls button.primary { background:var(--green); color:#fff; border-color:var(--green); }
  .meta { font-size:13px; color:var(--muted); margin-bottom:20px; display:flex; gap:16px; flex-wrap:wrap; align-items:center; }
  .warn { color:#b45309; }
  .err { color:#b91c1c; font-weight:700; min-height:1.4em; }
  table { width:100%; border-collapse:collapse; background:#fff; border-radius:12px; overflow:hidden; }
  th, td { text-align:left; padding:12px 14px; border-bottom:1px solid var(--line); font-size:16px; vertical-align:top; }
  th { background:#fafafa; font-size:13px; color:var(--muted); }
  tr.today td { background:#ecfdf3; }
  td.note { color:var(--green); font-weight:700; }
  tr.flash td { animation: flash 1.2s ease-out; }
  @keyframes flash { 0% { background:#fde68a; } 100% { background:transparent; } }
  .week { display:none; grid-template-columns:1fr 1fr; gap:16px; margin-top:20px; }
  .week.show { display:grid; }
  .card { background:#fff; border-radius:12px; padding:16px; border:1px solid var(--line); }
  .card h2 { font-size:16px; margin:0 0 8px; }
  .card.with { border:2px solid var(--green); }
  .big { font-size:28px; font-weight:800; margin:4px 0 10px; }
  .card ol { margin:0; padding-left:0; list-style:none; font-size:14px; }
  .card li { padding:4px 0; border-top:1px dashed var(--line); }
  .side { width:380px; height:calc(100vh - 48px); border:0; border-radius:16px; box-shadow:0 2px 12px rgba(0,0,0,.08); display:none; }
  .side.show { display:block; }
  label.toggle { display:inline-flex; gap:6px; align-items:center; }
</style></head><body>
<div class="wrap">
  <div class="main">
    <h1>デモ操作ページ</h1>
    <div class="clock" id="clock">-</div>
    <div class="controls">
      <button class="primary" data-act="wed">水曜 18:00</button>
      <button data-act="noreply">返事なしで30分</button>
      <button class="primary" data-act="sat">土曜</button>
      <button data-act="reset">リセット</button>
    </div>
    <div class="err" id="err"></div>
    <div class="meta">
      <span id="status"></span>
      <label class="toggle"><input type="checkbox" id="browserMode"> ブラウザ版で見せる（LINEに送らない）</label>
    </div>
    <table>
      <thead><tr><th>曜日</th><th>献立</th><th>組み直し</th></tr></thead>
      <tbody id="menu"></tbody>
    </table>
    <div class="week" id="week">
      <div class="card"><h2>アプリなしの1週間</h2><div class="big" id="withoutBig"></div><ol id="withoutList"></ol></div>
      <div class="card with"><h2>アプリありの1週間</h2><div class="big" id="withBig"></div><ol id="withList"></ol></div>
    </div>
  </div>
  <iframe class="side" id="side" src="/chat"></iframe>
</div>
<script>
const DAY = { mon:"月", tue:"火", wed:"水", thu:"木", fri:"金", sat:"土" };
let lastVersion = 0;
let current;

async function act(name, body) {
  document.getElementById("err").textContent = "";
  const res = await fetch("/api/demo/" + name, { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(body ?? {}) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) document.getElementById("err").textContent = json.error ?? "失敗しました";
  refresh();
}

document.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", () => act(b.dataset.act)));
document.getElementById("browserMode").addEventListener("change", (e) => act("channel", { channel: e.target.checked ? "browser" : "line" }));

function weekHtml(w) {
  return w.timeline.map((l) => "<li><b>" + DAY[l.day] + "</b> " + l.text + "</li>").join("");
}

function render({ state, week, meta }) {
  current = state;
  document.getElementById("clock").textContent = DAY[state.day] + "曜 " + state.time;
  const st = [];
  st.push(meta.lineConfigured ? "LINE接続済み" : "LINE未設定");
  if (meta.lineConfigured) st.push(meta.hasUser ? "送り先あり" : "<span class=warn>送り先なし（Botに何か送ってください）</span>");
  st.push(meta.storeKind === "redis" ? "状態: Redis" : "<span class=warn>状態: メモリ</span>");
  document.getElementById("status").innerHTML = st.join(" · ");
  const browser = state.channel === "browser";
  document.getElementById("browserMode").checked = browser;
  document.getElementById("side").classList.toggle("show", browser || !meta.lineConfigured);

  const flash = state.version !== lastVersion && lastVersion !== 0;
  lastVersion = state.version;
  document.getElementById("menu").innerHTML = state.menu.map((m) => {
    const cls = [m.day === state.day ? "today" : "", flash && state.changedDays.includes(m.day) ? "flash" : ""].join(" ");
    const dish = m.ingredients.length === 0 && m.note ? "<s>" + m.dish + "</s>" : m.dish;
    return "<tr class='" + cls + "'><td>" + DAY[m.day] + "</td><td>" + dish + "</td><td class=note>" + (m.note ?? "") + "</td></tr>";
  }).join("");

  const show = state.day === "sat";
  document.getElementById("week").classList.toggle("show", show);
  if (show) {
    document.getElementById("withoutBig").textContent = "捨てたもの " + week.without.wasted.length + "品";
    document.getElementById("withBig").textContent = "捨てたもの " + week.with.wasted.length + "品";
    document.getElementById("withoutList").innerHTML = weekHtml(week.without) + (week.without.wasted.length ? "<li>捨てた：" + week.without.wasted.join("・") + "</li>" : "");
    document.getElementById("withList").innerHTML = weekHtml(week.with) + "<li>崩れた日にも自分で食べた回数：" + week.with.selfMealsOnBadDays + "</li>";
  }
}

async function refresh() {
  try {
    const res = await fetch("/api/state");
    render(await res.json());
  } catch (e) {}
}
refresh();
setInterval(refresh, 1000);
</script>
</body></html>`;
}

export function chatPage(): string {
  return `<!doctype html><html lang="ja"><head>${base}
<title>ブラウザ版</title>
<style>
  body { background:#8cabd9; height:100vh; display:flex; flex-direction:column; }
  header { background:#fff; padding:12px 16px; font-weight:700; text-align:center; }
  #log { flex:1; overflow-y:auto; padding:12px; display:flex; flex-direction:column; gap:10px; }
  .row { display:flex; }
  .row.user { justify-content:flex-end; }
  .bubble { max-width:80%; padding:10px 14px; border-radius:18px; background:#fff; white-space:pre-wrap; line-height:1.5; }
  .user .bubble { background:#9ce57a; }
  .card { background:#fff; border-radius:16px; overflow:hidden; width:85%; }
  .card .body { padding:14px; }
  .card .title { font-size:12px; color:#888; margin-bottom:6px; }
  .card .text { font-weight:700; font-size:17px; line-height:1.5; }
  .card .btns { display:flex; gap:8px; padding:0 14px 14px; }
  .card .btns button { flex:1; padding:10px; border-radius:8px; border:0; background:#eee; font-weight:700; }
  .card .btns button.primary { background:var(--green); color:#fff; }
  .card .head { background:var(--green); color:#fff; font-weight:700; padding:12px 14px; }
  .stat { display:flex; justify-content:space-between; align-items:center; padding:6px 0; }
  .stat b { font-size:28px; color:var(--green); }
  form { display:flex; gap:8px; padding:10px; background:#fff; }
  input { flex:1; padding:10px 12px; border-radius:20px; border:1px solid #ddd; font:inherit; }
  form button { border:0; background:var(--green); color:#fff; border-radius:20px; padding:0 16px; font-weight:700; }
</style></head><body>
<header>救済Bot</header>
<div id="log"></div>
<form id="f"><input id="t" placeholder="デモ / ふり返り / リセット"><button>送信</button></form>
<script>
let lastCount = -1;
function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c])); }

function msgHtml(entry) {
  const m = entry.msg;
  if (m.kind === "text") return "<div class='row " + entry.from + "'><div class=bubble>" + esc(m.text) + "</div></div>";
  if (m.kind === "ask") {
    const btns = m.buttons.map((b) => "<button class='" + (b.primary ? "primary" : "") + "' data-pb='" + esc(b.data) + "'>" + esc(b.label) + "</button>").join("");
    return "<div class=row><div class=card><div class=body><div class=title>" + esc(m.title) + "</div><div class=text>" + esc(m.text) + "</div></div><div class=btns>" + btns + "</div></div></div>";
  }
  return "<div class=row><div class=card><div class=head>今週のふり返り</div><div class=body>" +
    "<div class=stat>今週捨てたもの<b>" + m.wasted + "</b></div>" +
    "<div class=stat>崩れた日にも自分で食べた回数<b>" + m.selfMeals + "</b></div></div></div></div>";
}

async function send(body) {
  await fetch("/api/chat", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(body) });
  refresh();
}

document.getElementById("log").addEventListener("click", (e) => {
  const pb = e.target.dataset && e.target.dataset.pb;
  if (pb) send({ postback: pb });
});
document.getElementById("f").addEventListener("submit", (e) => {
  e.preventDefault();
  const t = document.getElementById("t");
  if (t.value.trim()) send({ text: t.value });
  t.value = "";
});

async function refresh() {
  try {
    const { state } = await (await fetch("/api/state")).json();
    const key = state.chat.length + ":" + (state.chat.at(-1)?.at ?? 0);
    if (key === lastCount) return;
    lastCount = key;
    const log = document.getElementById("log");
    log.innerHTML = state.chat.map(msgHtml).join("");
    log.scrollTop = log.scrollHeight;
  } catch (e) {}
}
refresh();
setInterval(refresh, 1000);
</script>
</body></html>`;
}
