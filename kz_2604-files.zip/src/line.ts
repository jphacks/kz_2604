// 中立なメッセージを LINE の Flex Message に変換し、返信・プッシュする
import { messagingApi } from "@line/bot-sdk";
import type { Msg } from "./engine.js";

const token = process.env.LINE_CHANNEL_ACCESS_TOKEN;
export const channelSecret = process.env.LINE_CHANNEL_SECRET;
export const lineConfigured = Boolean(token && channelSecret);

const client = token ? new messagingApi.MessagingApiClient({ channelAccessToken: token }) : undefined;

const GREEN = "#06C755";

function toLine(msg: Msg): messagingApi.Message {
  if (msg.kind === "text") return { type: "text", text: msg.text };

  if (msg.kind === "ask") {
    // クイックリプライはPC版LINEに出ないので、ボタンはFlexのポストバックにする
    return {
      type: "flex",
      altText: `${msg.title} ${msg.text}`,
      contents: {
        type: "bubble",
        body: {
          type: "box",
          layout: "vertical",
          spacing: "md",
          contents: [
            { type: "text", text: msg.title, size: "sm", color: "#888888" },
            { type: "text", text: msg.text, wrap: true, size: "lg", weight: "bold" },
          ],
        },
        footer: {
          type: "box",
          layout: "horizontal",
          spacing: "md",
          contents: msg.buttons.map((b) => ({
            type: "button",
            style: b.primary ? "primary" : "secondary",
            color: b.primary ? GREEN : undefined,
            action: { type: "postback", label: b.label, data: b.data, displayText: b.label },
          })),
        },
      },
    };
  }

  return {
    type: "flex",
    altText: `今週のふり返り：捨てたもの ${msg.wasted}／崩れた日にも自分で食べた回数 ${msg.selfMeals}`,
    contents: {
      type: "bubble",
      header: {
        type: "box",
        layout: "vertical",
        backgroundColor: GREEN,
        contents: [{ type: "text", text: "今週のふり返り", color: "#FFFFFF", weight: "bold", size: "lg" }],
      },
      body: {
        type: "box",
        layout: "vertical",
        spacing: "lg",
        contents: [
          statRow("今週捨てたもの", `${msg.wasted}`),
          statRow("崩れた日にも自分で食べた回数", `${msg.selfMeals}`),
          { type: "text", text: "疲れた日があっても、ちゃんと回せた1週間でした", wrap: true, size: "sm", color: "#666666" },
        ],
      },
    },
  };
}

function statRow(label: string, value: string): messagingApi.FlexComponent {
  return {
    type: "box",
    layout: "horizontal",
    contents: [
      { type: "text", text: label, wrap: true, flex: 4, size: "md", gravity: "center" },
      { type: "text", text: value, flex: 1, size: "xxl", weight: "bold", align: "end", color: GREEN },
    ],
  };
}

export async function reply(replyToken: string, messages: Msg[]): Promise<void> {
  if (!client || messages.length === 0) return;
  await client.replyMessage({ replyToken, messages: messages.slice(0, 5).map(toLine) });
}

export async function push(to: string, messages: Msg[]): Promise<void> {
  if (!client || messages.length === 0) return;
  await client.pushMessage({ to, messages: messages.slice(0, 5).map(toLine) });
}
